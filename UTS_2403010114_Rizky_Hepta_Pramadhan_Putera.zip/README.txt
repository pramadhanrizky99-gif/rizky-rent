RIZKY RENT - PROYEK UTS PEMROGRAMAN WEB DAN INTERNET
Nama: Rizky Hepta Pramadhan Putera
NIM: 2403010114

CARA MENJALANKAN:
1. Ekstrak folder ZIP.
2. Buka folder Rizky_Rent_UTS.
3. Klik dua kali index.html atau buka folder melalui VS Code.
4. Jika memakai VS Code, install ekstensi Live Server lalu klik kanan index.html > Open with Live Server.

DAFTAR HALAMAN:
index.html (Beranda), armada.html, layanan.html, harga.html, tentang.html, faq.html, kontak.html.

TEKNOLOGI:
HTML5, CSS3, JavaScript. Seluruh class dan ID CSS menggunakan awalan rizky_ sesuai contoh aturan penamaan pada soal (#andi_header menjadi #rizky_header).

CATATAN:
Harga dan identitas kontak merupakan data simulasi untuk tugas akademik. Form kontak melakukan validasi di browser dan menampilkan pesan berhasil, tetapi belum terhubung ke backend/email.
